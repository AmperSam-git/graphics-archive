---------------------------------
-----Ripped by BlackEagle766-----
---------------------------------
Kirby's Dream Course background which is found in world 4 (Originally this was a Layer 3 BG).

Credit is not needed. Enjoy!
LM1.70 was used for this rip.
---------------------------------
----------Other details----------
---------------------------------
This rip uses stuff. It uses slots BG2 & BG3.
The Background does not repeat, so it's recommended to set layer 2 scrolling for horizontal and vertical to none.

ExGFX 540 = BG2
ExGFX 541 = BG3


