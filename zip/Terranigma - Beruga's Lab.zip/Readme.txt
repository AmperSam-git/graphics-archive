EXGFX80 = BG1

This Background looks from the Map16Pages bad,but this background is very good!