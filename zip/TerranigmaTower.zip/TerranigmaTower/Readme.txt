EXGFX83 = BG1
EXGFX84 = FG2

Note:
This Background damages 25% of FG2.